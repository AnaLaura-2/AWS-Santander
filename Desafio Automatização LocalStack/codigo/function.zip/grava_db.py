import logging
import boto3
import os
import json
from decimal import Decimal

logger = logging.getLogger()
logger.setLevel(logging.INFO)

endpoint_url = os.environ.get('AWS_ENDPOINT_URL')

dynamodb = boto3.resource('dynamodb', endpoint_url=endpoint_url)
s3 = boto3.client('s3', endpoint_url=endpoint_url)

TABLE_NAME = os.environ.get('TABLE_NAME')
table = dynamodb.Table(TABLE_NAME)

def lambda_handler(event, context):
    logger.info(f"Evento recebido: {json.dumps(event)}")
    try:
        s3_event = event['Records'][0]['s3']
        bucket_name = s3_event['bucket']['name']
        object_key = s3_event['object']['key']
        
        response = s3.get_object(Bucket=bucket_name, Key=object_key)
        content = response['Body'].read().decode('utf-8')
        records = json.loads(content, parse_float=Decimal)

        with table.batch_writer() as batch:
            for record in records:
                batch.put_item(Item=record)
        
        logger.info(f"Sucesso! {len(records)} registros inseridos.")
        return {"statusCode": 200, "body": "Registros inseridos com sucesso."}

    except Exception as e:
        logger.error(f"Erro ao processar o evento: {e}")
        return {"statusCode": 500, "body": "Erro ao processar o arquivo."}